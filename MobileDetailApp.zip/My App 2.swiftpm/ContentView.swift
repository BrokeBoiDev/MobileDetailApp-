import SwiftUI

// Designed & Developed By @GHOSTBYTELABS

// MARK: - Models

struct ServicePackage: Identifiable, Hashable {
    let id = UUID()
    let name: String
    let price: String
    let duration: String
    let includes: [String]
}

struct Booking: Hashable {
    var package: ServicePackage?
    var name: String = ""
    var phone: String = ""
    var address: String = ""
    var date: Date = Date()
    var notes: String = ""
}

// MARK: - ViewModel

final class DetailAppVM: ObservableObject {
    @Published var packages: [ServicePackage] = [
        .init(name: "Exterior Wash", price: "$60", duration: "45–60 min", includes: ["Hand wash", "Wheel clean", "Tire shine"]),
        .init(name: "Interior Detail", price: "$120", duration: "1.5–2 hr", includes: ["Vacuum", "Wipe down", "Windows", "Light stain treatment"]),
        .init(name: "Full Detail", price: "$180", duration: "2–3 hr", includes: ["Exterior + Interior", "Spray wax", "Trim dress"]),
        .init(name: "Premium (Ceramic Spray)", price: "$250", duration: "3–4 hr", includes: ["Full detail", "Clay (if needed)", "Ceramic spray sealant"])
    ]
    
    @Published var booking = Booking()
    
    // ✅ SAFE placeholder numbers (reserved 555 examples)
    let businessName = "Your Mobile Detail Co."
    let phoneNumberDigits = "12025550147" // +1 (202) 555-0147 (example)
    let smsNumberDigits   = "12025550147"
}

// MARK: - Helpers

func digitsOnly(_ s: String) -> String {
    s.filter(\.isNumber)
}

// MARK: - Root (Crash-proof)

struct ContentView: View {
    @StateObject private var vm = DetailAppVM()
    
    var body: some View {
        TabView {
            HomeView()
                .tabItem { Label("Home", systemImage: "house.fill") }
            
            ServicesView()
                .tabItem { Label("Services", systemImage: "list.bullet") }
            
            BookingView()
                .tabItem { Label("Book", systemImage: "calendar") }
        }
        .environmentObject(vm) // ✅ prevents missing EnvironmentObject crash
    }
}

// MARK: - Home

struct HomeView: View {
    @EnvironmentObject var vm: DetailAppVM
    @Environment(\.openURL) private var openURL
    
    var body: some View {
        NavigationStack {
            ScrollView(showsIndicators: false) {
                VStack(alignment: .leading, spacing: 16) {
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text(vm.businessName)
                            .font(.largeTitle).bold()
                        Text("Mobile detailing at your home or work.")
                            .foregroundStyle(.secondary)
                    }
                    
                    HStack(spacing: 12) {
                        Button {
                            if let url = URL(string: "tel://\(vm.phoneNumberDigits)") { openURL(url) }
                        } label: {
                            Label("Call", systemImage: "phone.fill")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.borderedProminent)
                        
                        Button {
                            if let url = URL(string: "sms:\(vm.smsNumberDigits)") { openURL(url) }
                        } label: {
                            Label("Text", systemImage: "message.fill")
                                .frame(maxWidth: .infinity)
                        }
                        .buttonStyle(.bordered)
                    }
                    
                    VStack(alignment: .leading, spacing: 8) {
                        Text("Why us")
                            .font(.headline)
                        Text("• Professional tools + safe products\n• Fast scheduling\n• Clear pricing\n• We come to you")
                            .foregroundStyle(.secondary)
                    }
                    .padding()
                    .background(.thinMaterial)
                    .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
                    
                    VStack(alignment: .leading, spacing: 10) {
                        Text("Popular Packages")
                            .font(.headline)
                        
                        ForEach(vm.packages.prefix(3)) { p in
                            PackageCard(package: p)
                                .contentShape(Rectangle())
                                .onTapGesture { vm.booking.package = p }
                        }
                    }
                    
                    NavigationLink {
                        BookingView()
                    } label: {
                        Text("Book Now")
                            .font(.headline)
                            .frame(maxWidth: .infinity)
                    }
                    .buttonStyle(.borderedProminent)
                    .padding(.top, 6)
                    
                    Text("Designed & Developed By @GHOSTBYTELABS")
                        .font(.caption)
                        .foregroundStyle(.secondary)
                        .padding(.top, 8)
                }
                .padding()
            }
            .navigationTitle("Welcome")
        }
    }
}

// MARK: - Services

struct ServicesView: View {
    @EnvironmentObject var vm: DetailAppVM
    
    var body: some View {
        NavigationStack {
            List {
                ForEach(vm.packages) { p in
                    VStack(alignment: .leading, spacing: 6) {
                        HStack {
                            Text(p.name).font(.headline)
                            Spacer()
                            Text(p.price).font(.headline)
                        }
                        
                        Text("\(p.duration) • " + p.includes.joined(separator: " • "))
                            .foregroundStyle(.secondary)
                            .font(.subheadline)
                        
                        Button("Select") { vm.booking.package = p }
                            .buttonStyle(.bordered)
                            .padding(.top, 6)
                    }
                    .padding(.vertical, 6)
                }
            }
            .navigationTitle("Services")
        }
    }
}

// MARK: - Booking

struct BookingView: View {
    @EnvironmentObject var vm: DetailAppVM
    @State private var showConfirmation = false
    @State private var errorMsg: String?
    
    var body: some View {
        NavigationStack {
            Form {
                Section("Package") {
                    Picker("Choose", selection: $vm.booking.package) {
                        Text("Select a package").tag(ServicePackage?.none)
                        ForEach(vm.packages) { p in
                            Text("\(p.name) • \(p.price)").tag(ServicePackage?.some(p))
                        }
                    }
                }
                
                Section("Your Info") {
                    TextField("Name", text: $vm.booking.name)
                        .textContentType(.name)
                    
                    TextField("Phone", text: $vm.booking.phone)
                        .keyboardType(.phonePad)
                }
                
                Section("Location") {
                    TextField("Address", text: $vm.booking.address)
                }
                
                Section("Schedule") {
                    DatePicker("Date & Time",
                               selection: $vm.booking.date,
                               displayedComponents: [.date, .hourAndMinute])
                }
                
                Section("Notes (optional)") {
                    TextField("Vehicle type, heavy pet hair, etc.",
                              text: $vm.booking.notes,
                              axis: .vertical)
                    .lineLimit(3...6)
                }
                
                if let errorMsg {
                    Section { Text(errorMsg).foregroundStyle(.red) }
                }
                
                Section {
                    Button("Review Booking") {
                        if validate() { showConfirmation = true }
                    }
                    .buttonStyle(.borderedProminent)
                }
            }
            .navigationTitle("Book")
            .sheet(isPresented: $showConfirmation) {
                BookingConfirmationView()
            }
        }
    }
    
    private func validate() -> Bool {
        errorMsg = nil
        
        if vm.booking.package == nil { errorMsg = "Please select a package."; return false }
        if vm.booking.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { errorMsg = "Enter your name."; return false }
        
        let phoneDigits = digitsOnly(vm.booking.phone)
        if phoneDigits.count < 10 { errorMsg = "Enter a valid phone number."; return false }
        
        if vm.booking.address.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty { errorMsg = "Enter an address."; return false }
        
        return true
    }
}

// MARK: - Confirmation

struct BookingConfirmationView: View {
    @EnvironmentObject var vm: DetailAppVM
    @Environment(\.dismiss) private var dismiss
    @Environment(\.openURL) private var openURL
    
    var body: some View {
        NavigationStack {
            VStack(alignment: .leading, spacing: 14) {
                Text("Confirm Your Booking")
                    .font(.title2).bold()
                
                if let p = vm.booking.package {
                    SummaryRow(title: "Package", value: "\(p.name) (\(p.price))")
                    SummaryRow(title: "Duration", value: p.duration)
                }
                
                SummaryRow(title: "Name", value: vm.booking.name)
                SummaryRow(title: "Phone", value: vm.booking.phone)
                SummaryRow(title: "Address", value: vm.booking.address)
                SummaryRow(title: "Date", value: vm.booking.date.formatted(date: .abbreviated, time: .shortened))
                
                if !vm.booking.notes.isEmpty {
                    SummaryRow(title: "Notes", value: vm.booking.notes)
                }
                
                Spacer()
                
                Button {
                    let pName = vm.booking.package?.name ?? "Package"
                    let text = """
                    Booking Request:
                    \(pName)
                    Name: \(vm.booking.name)
                    Phone: \(vm.booking.phone)
                    Address: \(vm.booking.address)
                    Date: \(vm.booking.date.formatted(date: .abbreviated, time: .shortened))
                    Notes: \(vm.booking.notes.isEmpty ? "None" : vm.booking.notes)
                    """
                    
                    let encoded = text.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed) ?? ""
                    
                    // ✅ Safer iOS format
                    if let url = URL(string: "sms:\(vm.smsNumberDigits)?&body=\(encoded)") {
                        openURL(url)
                    }
                } label: {
                    Label("Text to Confirm", systemImage: "message.fill")
                        .frame(maxWidth: .infinity)
                }
                .buttonStyle(.borderedProminent)
                
                Button("Close") { dismiss() }
                    .frame(maxWidth: .infinity)
                    .buttonStyle(.bordered)
            }
            .padding()
            .navigationTitle("Confirmation")
        }
    }
}

// MARK: - UI Bits

struct PackageCard: View {
    let package: ServicePackage
    
    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            HStack {
                Text(package.name).font(.headline)
                Spacer()
                Text(package.price).font(.headline)
            }
            Text("\(package.duration) • " + package.includes.joined(separator: " • "))
                .font(.subheadline)
                .foregroundStyle(.secondary)
        }
        .padding()
        .background(.thinMaterial)
        .clipShape(RoundedRectangle(cornerRadius: 16, style: .continuous))
    }
}

struct SummaryRow: View {
    let title: String
    let value: String
    
    var body: some View {
        VStack(alignment: .leading, spacing: 4) {
            Text(title).font(.caption).foregroundStyle(.secondary)
            Text(value).font(.body)
        }
    }
}
